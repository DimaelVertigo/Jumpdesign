<?php

class ffConstActions extends ffBasicObject {
	const FILTER_QUERY_GET_ICON = 'ff_filter_query_get_icon';
	const FILTER_GET_FONTS = 'ff_filter_get_fonts';

    const ACTION_QUERY_NOT_FOUND_IN_DATA = 'ff_action_query_not_found_in_data';
}