<?php

class ffTaxAdminColumns extends ffBasicObject{

}