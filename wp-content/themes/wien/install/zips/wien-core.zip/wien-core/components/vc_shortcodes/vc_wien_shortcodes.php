<?php

if( function_exists('vc_map') ){

	require dirname( __FILE__ ) . '/wien-progressbar.php';

}
