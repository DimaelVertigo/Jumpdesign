<?php

$info = array();
$info['plugin-name'] = 'wien-core';
$info['plugin-version'] = '1.0.0';